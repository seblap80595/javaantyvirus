
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Scanner;
import java.time.LocalDateTime;
import javax.swing.plaf.PanelUI;
import java.security.NoSuchAlgorithmException;

public class Main {
    public static void Main(String[] args) /*throws IOException */  throws NoSuchAlgorithmException{
        eadFile inf = new eadFile();
        String ipsexp = inf.xep();
        System.out.println(ipsexp);
        if (ipsexp =="204.81.212.72") {
            System.out.println("true");
        } else {
            System.out.println("false");
        } 
        LocalDateTime time = LocalDateTime.now();
        System.out.println(time); 
        printlis();
    } 
    public static void printlis() throws NoSuchAlgorithmException{
        hash lis = new hash();
        String xil = lis.create();
        System.out.println(xil);
    } 
}
/*        File fipsexp = new File("ipaccp.txt");
        Scanner rfipse = new Scanner(fipsexp);
        while (rfipse.hasNextLine()); */