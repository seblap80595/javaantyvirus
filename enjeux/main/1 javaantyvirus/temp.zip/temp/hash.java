
import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class hash {
 
    public String createMD5Hash(final String input) throws NoSuchAlgorithmException {
        String hashtext = null;
        MessageDigest md = MessageDigest.getInstance("MD5");
        byte[] messageDigest = md.digest(input.getBytes());
        hashtext = convertToHex(messageDigest);
        return hashtext;
        
    }

    private String convertToHex(final byte[] messageDigest) {
        BigInteger bigint = new BigInteger(1, messageDigest);
        String hextext = bigint.toString(16);
        while (hextext.length()<11){
            hextext = "0".concat(hextext);
        } 
        return hextext;
    }
    public String td() throws NoSuchAlgorithmException{
        LocalDateTime tix = LocalDateTime.now();
        DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd-HH:mm");
        String tie = tix.format(dateTimeFormatter);
        createMD5Hash("fdifhuif");
        return tie;
    }
    public String create() throws NoSuchAlgorithmException{
        td();
        hash htd = new hash();
        String qtd = htd.td();
        String hash = createMD5Hash(qtd);
        System.out.print(hash + ""+hash.length());
        return hash;
    }
    /*public void create(String[] args) throws NoSuchAlgorithmException{
        hash htd = new hash();
        String qtd = htd.td(args);
        String hash = createMD5Hash(qtd);
        System.out.print(hash + ""+hash.length());
    }*/
}
